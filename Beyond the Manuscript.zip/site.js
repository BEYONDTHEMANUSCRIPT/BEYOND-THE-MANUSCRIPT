/* Beyond the Manuscript: shared behaviour.
   Edit CONFIG with your own details. Leave a value empty to hide it. */
var CONFIG = {
  email: "",          /* e.g. "hello@yourdomain.com". Hidden until filled in. */
  discordInvite: "",  /* paste your Discord invite link, e.g. https://discord.gg/xxxxxx */
  reddit: "https://www.reddit.com/r/BeyondtheManuscript/",
  socials: [
    { label: "Instagram", url: "" },
    { label: "X", url: "" },
    { label: "LinkedIn", url: "" },
    { label: "Threads", url: "" },
    { label: "TikTok", url: "" }
  ]
};

(function () {
  var doc = document, root = doc.documentElement;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  function all(sel, ctx) { return Array.prototype.slice.call((ctx || doc).querySelectorAll(sel)); }

  /* ---- Config-driven content ---- */
  all("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
  all("[data-discord]").forEach(function (a) {
    if (CONFIG.discordInvite) {
      a.href = CONFIG.discordInvite; a.target = "_blank"; a.rel = "noopener";
      a.textContent = a.getAttribute("data-label") || "Join the Discord";
      a.removeAttribute("aria-disabled");
    }
  });
  all("[data-email-wrap]").forEach(function (el) { el.hidden = !CONFIG.email; });
  all("[data-email-text]").forEach(function (el) { el.textContent = CONFIG.email; });
  var links = [];
  if (CONFIG.discordInvite) links.push({ label: "Discord", url: CONFIG.discordInvite });
  if (CONFIG.reddit) links.push({ label: "Reddit", url: CONFIG.reddit });
  links = links.concat(CONFIG.socials.filter(function (s) { return s.url; }));
  all("[data-socials]").forEach(function (box) {
    links.forEach(function (s) {
      var a = doc.createElement("a");
      a.href = s.url; a.target = "_blank"; a.rel = "noopener"; a.textContent = s.label;
      box.appendChild(a);
    });
  });

  /* ---- Header state ---- */
  var hdr = doc.querySelector(".hdr");
  function onScrollHdr() { if (hdr) hdr.classList.toggle("is-solid", window.scrollY > 30); }
  onScrollHdr();

  /* ---- Mobile menu ---- */
  var btn = doc.querySelector(".menu-btn"), panel = doc.getElementById("mnav");
  function setMenu(open) {
    if (!btn || !panel) return;
    panel.classList.toggle("open", open);
    root.classList.toggle("menu-open", open);
    doc.body.classList.toggle("menu-open", open);
    btn.setAttribute("aria-expanded", open ? "true" : "false");
    btn.querySelector("span").textContent = open ? "Close" : "Menu";
    panel.setAttribute("aria-hidden", open ? "false" : "true");
    all("a", panel).forEach(function (a) { a.tabIndex = open ? 0 : -1; });
    if (open) { var first = panel.querySelector("a"); if (first) first.focus(); } else { btn.focus({ preventScroll: true }); }
  }
  if (btn && panel) {
    all("a", panel).forEach(function (a) { a.tabIndex = -1; });
    btn.addEventListener("click", function () { setMenu(!panel.classList.contains("open")); });
    all("a", panel).forEach(function (a) { a.addEventListener("click", function () { setMenu(false); }); });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape" && panel.classList.contains("open")) setMenu(false); });
    window.matchMedia("(min-width: 961px)").addEventListener("change", function (m) { if (m.matches && panel.classList.contains("open")) setMenu(false); });
  }

  /* ---- Scroll reveals: hide only what is below the fold, reveal in sequence ---- */
  var rv = all("[data-rv]");
  rv.forEach(function (el) {
    var group = el.closest("[data-stagger]");
    if (group && !el.style.getPropertyValue("--d")) {
      var sibs = all("[data-rv]", group);
      el.style.setProperty("--d", String(sibs.indexOf(el) * 110));
    }
  });
  if (!reduce && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.remove("pre"); io.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    rv.forEach(function (el) {
      var r = el.getBoundingClientRect();
      if (r.top > window.innerHeight * 0.92) { el.classList.add("pre"); io.observe(el); }
    });
  }

  /* ---- Scroll parallax for selected artwork ---- */
  var px = all("[data-speed]");
  var ticking = false;
  function updatePx() {
    ticking = false;
    var h = window.innerHeight;
    px.forEach(function (el) {
      var box = el.parentNode.getBoundingClientRect();
      if (box.bottom < -300 || box.top > h + 300) return;
      var c = box.top + box.height / 2 - h / 2;
      el.style.setProperty("--py", (c * parseFloat(el.getAttribute("data-speed"))).toFixed(1) + "px");
    });
  }
  function onScroll() { onScrollHdr(); if (!reduce && !ticking) { ticking = true; requestAnimationFrame(updatePx); } }
  window.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onScroll);
  if (!reduce) updatePx();

  /* ---- Pointer depth on the hero book (desktop only) ---- */
  var hero = doc.querySelector("[data-depth-scope]"), art = doc.querySelector("[data-depth]");
  if (hero && art && fine && !reduce) {
    var raf = 0, tx = 0, ty = 0;
    hero.addEventListener("pointermove", function (e) {
      var r = hero.getBoundingClientRect();
      tx = ((e.clientX - r.left) / r.width - 0.5) * 2;
      ty = ((e.clientY - r.top) / r.height - 0.5) * 2;
      if (!raf) raf = requestAnimationFrame(function () { raf = 0; art.style.setProperty("--mx", tx.toFixed(3)); art.style.setProperty("--my", ty.toFixed(3)); });
    });
    hero.addEventListener("pointerleave", function () { art.style.setProperty("--mx", "0"); art.style.setProperty("--my", "0"); });
  }

  /* ---- Copy helpers ---- */
  function copyText(text, onOk, onFail) {
    try { navigator.clipboard.writeText(text).then(onOk, onFail); } catch (e) { onFail(); }
  }
  all("[data-copy-email]").forEach(function (b) {
    b.addEventListener("click", function () {
      var label = b.textContent;
      copyText(CONFIG.email, function () { b.textContent = "Copied"; setTimeout(function () { b.textContent = label; }, 1800); }, function () { b.textContent = "Select the address"; });
    });
  });

  /* ---- Contact brief ---- */
  var form = doc.getElementById("brief-form");
  if (form) {
    var out = doc.getElementById("brief-out"), copyBtn = doc.getElementById("brief-copy"), status = doc.getElementById("brief-status");
    var fields = [
      ["b-name", "Name"], ["b-contact", "Best way to reach me"], ["b-genre", "Genre"], ["b-books", "Books published"],
      ["b-route", "Publishing route"], ["b-deadline", "Launch date or deadline"], ["b-links", "Author sites I like"], ["b-notes", "About my project"]
    ];
    var required = { "b-name": "Add your name so I know who the message is from.", "b-notes": "Add a sentence or two about your project." };
    function val(id) { return (doc.getElementById(id).value || "").trim(); }
    function build() {
      var lines = ["Hi Fenoir, I'd like to talk about a project."], body = [];
      fields.forEach(function (f) { var v = val(f[0]); if (v) body.push(f[1] + ": " + v); });
      out.value = body.length ? lines.concat([""], body).join("\n") : lines.join("\n");
    }
    function setErr(id, msg) {
      var input = doc.getElementById(id), err = doc.getElementById(id + "-err");
      input.setAttribute("aria-invalid", msg ? "true" : "false");
      if (err) err.textContent = msg || "";
    }
    function validate() {
      var firstBad = null;
      Object.keys(required).forEach(function (id) {
        var bad = !val(id); setErr(id, bad ? required[id] : "");
        if (bad && !firstBad) firstBad = id;
      });
      return firstBad;
    }
    function say(msg, ok) { status.textContent = msg; status.className = "status" + (ok ? " ok" : ""); }
    form.addEventListener("input", function (e) { build(); if (required[e.target.id] && val(e.target.id)) setErr(e.target.id, ""); });
    form.addEventListener("change", build);
    form.addEventListener("submit", function (e) { e.preventDefault(); copyBtn.click(); });
    copyBtn.addEventListener("click", function () {
      var bad = validate();
      if (bad) { say("Please fix the highlighted field" + (Object.keys(required).filter(function (i) { return !val(i); }).length > 1 ? "s" : "") + " first.", false); doc.getElementById(bad).focus(); return; }
      build();
      copyText(out.value, function () { say("Copied. Paste it into an email, a Discord message or a Reddit post. Nothing has been sent.", true); },
        function () { out.focus(); out.select(); say("Your browser blocked copying. The message is selected, so press Ctrl+C or Cmd+C.", false); });
    });
    build();
  }
})();
